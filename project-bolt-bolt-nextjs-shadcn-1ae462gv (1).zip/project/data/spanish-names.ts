export const spanishNames = {
  firstNames: [
    "Antonio", "José", "Manuel", "Francisco", "David", "Juan", "Miguel", "Javier",
    "María", "Carmen", "Ana", "Isabel", "Laura", "Sofia", "Elena", "Patricia"
  ],
  lastNames: [
    "García", "Rodríguez", "González", "Fernández", "López", "Martínez", "Sánchez",
    "Pérez", "Gómez", "Martin", "Jiménez", "Ruiz", "Hernández", "Díaz", "Moreno"
  ]
};